from robotica_plugins.kinematics.plugins.two_link_arm_kinematics import TwoLinkArmKinematics

Kinematics_Plugins = {
TwoLinkArmKinematics.__name__: TwoLinkArmKinematics,
}
