class WayPoint():
    def __init__(self, point, speed):
        self.point = point
        self.speed  = speed